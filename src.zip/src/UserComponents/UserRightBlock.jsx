import React from "react";
import { useParams } from "react-router-dom";
import Profile from "./profilecomponents/Profile";

// to import url parameters useparam
const UserRightBlock = () => {
  let { id } = useParams();
  return (
    <div className="userRightBlock">
      <h3>{id === "profile" && <Profile />}</h3>
    </div>
  );
};

export default UserRightBlock;
